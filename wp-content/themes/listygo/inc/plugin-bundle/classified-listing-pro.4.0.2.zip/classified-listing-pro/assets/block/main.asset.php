<?php return array('dependencies' => array('jquery', 'react', 'react-dom', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n'), 'version' => '6b8911a0030faf2451c8');
