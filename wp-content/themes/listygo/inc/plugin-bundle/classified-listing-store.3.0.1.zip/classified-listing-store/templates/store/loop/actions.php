<?php
/**
 * Result Count
 *
 */
?>

<div class="rtcl-stores-actions rtcl-listings-actions">
    <?php do_action('rtcl_store_loop_action'); ?>
</div>