<?php 
// Security check
defined('ABSPATH') || die();

class RTOptimizerHooks{


}